import { Cpu, Code2, BrainCircuit } from "lucide-react";

const categories = [
  {
    icon: Cpu,
    title: "Embedded & Robotics",
    skills: ["Arduino / Microcontrollers", "Sensor Integration", "Servo & Actuator Systems", "PCB Fundamentals"],
  },
  {
    icon: Code2,
    title: "Software & Systems",
    skills: ["Go Backend Development", "Rust Data Processing", "API Integration", "Database Design"],
  },
  {
    icon: BrainCircuit,
    title: "AI & Automation",
    skills: ["Workflow Automation (N8N)", "Data Processing Systems", "AI Integration Logic", "ML Model Deployment"],
  },
];

export default function CapabilitiesSection() {
  return (
    <section id="capabilities" className="section-padding">
      <div className="max-w-6xl mx-auto">
        <div className="gold-line mb-16" />

        <p className="text-primary font-display text-sm tracking-[0.2em] uppercase mb-4">
          Engineering Capabilities
        </p>
        <h2 className="font-display text-3xl md:text-4xl font-bold mb-16">
          Full-Stack <span className="text-gradient-gold">Hardware to Cloud</span>
        </h2>

        <div className="grid md:grid-cols-3 gap-6">
          {categories.map((cat) => (
            <div
              key={cat.title}
              className="bg-surface border border-border rounded-sm p-8 hover:border-primary/20 transition-colors"
            >
              <cat.icon size={28} className="text-primary mb-6" />
              <h3 className="font-display text-lg font-semibold mb-6">{cat.title}</h3>
              <ul className="space-y-3">
                {cat.skills.map((skill) => (
                  <li key={skill} className="flex items-center gap-3 text-sm text-muted-foreground">
                    <div className="w-1 h-1 rounded-full bg-primary shrink-0" />
                    {skill}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
