import { Users, Rocket, Handshake } from "lucide-react";

const milestones = [
  "Founded Version Extreme Cooperation with a 3-person engineering core",
  "Established multi-sector product strategy across 5 verticals",
  "Developed 3 flagship MVPs with real-world testing pipelines",
  "Engaged industry partners for pilot deployments",
];

export default function LeadershipSection() {
  return (
    <section className="section-padding">
      <div className="max-w-6xl mx-auto">
        <div className="gold-line mb-16" />

        <div className="grid md:grid-cols-2 gap-16">
          <div>
            <p className="text-primary font-display text-sm tracking-[0.2em] uppercase mb-4">
              Leadership
            </p>
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-6">
              Founder & <span className="text-gradient-gold">Lead Engineer</span>
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Leading a lean 3-person founding team where engineering excellence meets strategic execution.
              Every team member owns a vertical — from hardware R&D to software systems to business operations.
            </p>

            <div className="grid grid-cols-3 gap-4">
              {[
                { icon: Users, label: "3-Person Core" },
                { icon: Rocket, label: "5 Verticals" },
                { icon: Handshake, label: "Industry Partners" },
              ].map(({ icon: Icon, label }) => (
                <div key={label} className="text-center p-4 bg-surface rounded-sm border border-border">
                  <Icon size={20} className="text-primary mx-auto mb-2" />
                  <p className="text-xs font-display font-medium">{label}</p>
                </div>
              ))}
            </div>
          </div>

          <div>
            <p className="text-primary font-display text-sm tracking-[0.2em] uppercase mb-4">
              Execution Track
            </p>
            <div className="space-y-4">
              {milestones.map((m, i) => (
                <div key={i} className="flex items-start gap-4 p-4 bg-surface rounded-sm border border-border">
                  <div className="w-6 h-6 rounded-full border border-primary/30 flex items-center justify-center text-primary font-display text-xs font-bold shrink-0 mt-0.5">
                    {i + 1}
                  </div>
                  <p className="text-sm text-muted-foreground">{m}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
