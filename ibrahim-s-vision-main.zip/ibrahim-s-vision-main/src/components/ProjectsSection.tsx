import { ArrowUpRight } from "lucide-react";

const projects = [
  {
    name: "Smart Duka OS",
    tagline: "Retail Automation Platform",
    problem: "Small African retailers lack affordable digital tools for inventory, sales tracking, and analytics.",
    architecture: "Modular POS system with Go backend, real-time sync, offline-first architecture, and hardware integration.",
    stack: ["Go", "React", "PostgreSQL", "Arduino", "MQTT"],
    hardware: "Custom receipt printer integration, barcode scanners, IoT weight sensors",
    market: "50M+ small retailers across Sub-Saharan Africa",
    status: "MVP",
    lessons: "Offline-first is non-negotiable for African retail. Hardware reliability beats feature count.",
  },
  {
    name: "BodaGuard",
    tagline: "Urban Mobility Safety System",
    problem: "Motorcycle taxi (boda-boda) accidents kill thousands yearly due to reckless driving and no accountability.",
    architecture: "IoT-based real-time monitoring with GPS tracking, speed alerts, crash detection, and rider scoring.",
    stack: ["Rust", "Go", "React Native", "TimescaleDB", "LoRaWAN"],
    hardware: "Custom PCB with accelerometer, GPS module, GSM connectivity, and vibration motor",
    market: "5M+ boda-boda riders in East Africa alone",
    status: "Testing",
    lessons: "Low-power design is critical. Cellular fallback needed where LoRa coverage is sparse.",
  },
  {
    name: "KukuSmart",
    tagline: "AI-Powered Poultry Management",
    problem: "Poultry farmers lose 30%+ of flock due to poor environment monitoring and disease detection delays.",
    architecture: "Sensor mesh network monitoring temperature, humidity, ammonia. ML models for anomaly detection.",
    stack: ["Python", "Go", "TensorFlow Lite", "React", "InfluxDB"],
    hardware: "ESP32 sensor nodes, environmental sensors (DHT22, MQ-135), automated ventilation actuators",
    market: "Growing demand for smart farming across Africa's $4.2B poultry industry",
    status: "MVP",
    lessons: "Farmers need SMS alerts, not apps. Simplicity drives adoption in rural contexts.",
  },
];

export default function ProjectsSection() {
  return (
    <section id="projects" className="section-padding">
      <div className="max-w-6xl mx-auto">
        <div className="gold-line mb-16" />

        <p className="text-primary font-display text-sm tracking-[0.2em] uppercase mb-4">
          Flagship Projects
        </p>
        <h2 className="font-display text-3xl md:text-4xl font-bold mb-16">
          Engineering <span className="text-gradient-gold">Proof</span>
        </h2>

        <div className="space-y-12">
          {projects.map((project) => (
            <div
              key={project.name}
              className="bg-surface border border-border rounded-sm p-6 md:p-10 hover:border-primary/20 transition-colors group"
            >
              <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-8">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="font-display text-2xl font-bold">{project.name}</h3>
                    <span className="text-xs px-2 py-0.5 rounded-sm bg-primary/10 text-primary font-display font-semibold uppercase tracking-wider">
                      {project.status}
                    </span>
                  </div>
                  <p className="text-muted-foreground text-sm">{project.tagline}</p>
                </div>
                <ArrowUpRight size={20} className="text-muted-foreground group-hover:text-primary transition-colors shrink-0" />
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div>
                    <p className="text-xs text-primary font-display uppercase tracking-wider mb-2">Problem</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">{project.problem}</p>
                  </div>
                  <div>
                    <p className="text-xs text-primary font-display uppercase tracking-wider mb-2">Architecture</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">{project.architecture}</p>
                  </div>
                  <div>
                    <p className="text-xs text-primary font-display uppercase tracking-wider mb-2">Hardware</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">{project.hardware}</p>
                  </div>
                </div>

                <div className="space-y-6">
                  <div>
                    <p className="text-xs text-primary font-display uppercase tracking-wider mb-2">Stack</p>
                    <div className="flex flex-wrap gap-2">
                      {project.stack.map((tech) => (
                        <span key={tech} className="text-xs px-3 py-1 bg-secondary text-secondary-foreground rounded-sm font-display">
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-xs text-primary font-display uppercase tracking-wider mb-2">Market Opportunity</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">{project.market}</p>
                  </div>
                  <div>
                    <p className="text-xs text-primary font-display uppercase tracking-wider mb-2">Key Lesson</p>
                    <p className="text-sm text-muted-foreground leading-relaxed italic">{project.lessons}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
