import { Mail, Linkedin, Github, MessageCircle } from "lucide-react";

const openTo = [
  "Strategic Partnerships",
  "Tech Collaborations",
  "Industry Pilots",
  "Engineering Opportunities",
];

const links = [
  { icon: Mail, label: "Email", href: "mailto:ibrahim@versionextreme.com", value: "ibrahim@versionextreme.com" },
  { icon: Linkedin, label: "LinkedIn", href: "#", value: "linkedin.com/in/ibrahim" },
  { icon: Github, label: "GitHub", href: "#", value: "github.com/ibrahim" },
  { icon: MessageCircle, label: "WhatsApp (Business)", href: "#", value: "Business inquiries only" },
];

export default function ContactSection() {
  return (
    <section id="contact" className="section-padding">
      <div className="max-w-4xl mx-auto">
        <div className="gold-line mb-16" />

        <div className="grid md:grid-cols-2 gap-16">
          <div>
            <p className="text-primary font-display text-sm tracking-[0.2em] uppercase mb-4">
              Open To
            </p>
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-8">
              Strategic <span className="text-gradient-gold">Opportunities</span>
            </h2>

            <div className="space-y-3">
              {openTo.map((item) => (
                <div key={item} className="flex items-center gap-3 p-4 bg-surface rounded-sm border border-border">
                  <div className="w-2 h-2 rounded-full bg-primary" />
                  <span className="text-sm font-display font-medium">{item}</span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <p className="text-primary font-display text-sm tracking-[0.2em] uppercase mb-4">
              Connect
            </p>

            <div className="space-y-4">
              {links.map(({ icon: Icon, label, href, value }) => (
                <a
                  key={label}
                  href={href}
                  className="flex items-center gap-4 p-4 bg-surface rounded-sm border border-border hover:border-primary/30 transition-colors group"
                >
                  <Icon size={20} className="text-primary shrink-0" />
                  <div>
                    <p className="text-xs text-muted-foreground mb-0.5">{label}</p>
                    <p className="text-sm font-display font-medium group-hover:text-primary transition-colors">{value}</p>
                  </div>
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="gold-line mt-20 mb-8" />
        <div className="text-center">
          <p className="text-xs text-muted-foreground font-display">
            © 2026 Version Extreme Cooperation. Engineering Africa's Future.
          </p>
        </div>
      </div>
    </section>
  );
}
