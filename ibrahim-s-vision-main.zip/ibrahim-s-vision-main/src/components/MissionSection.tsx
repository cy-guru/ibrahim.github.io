import { Eye } from "lucide-react";

const sectors = [
  "Smart Agriculture",
  "Urban Mobility & Safety",
  "Retail Automation",
  "Robotics Manufacturing",
  "Infrastructure Intelligence",
];

export default function MissionSection() {
  return (
    <section id="mission" className="section-padding">
      <div className="max-w-6xl mx-auto">
        <div className="gold-line mb-16" />

        <div className="grid md:grid-cols-2 gap-16">
          <div>
            <p className="text-primary font-display text-sm tracking-[0.2em] uppercase mb-4">
              Why Version Extreme
            </p>
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-6">
              Engineering Africa's <span className="text-gradient-gold">Industrial Future</span>
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Version Extreme Cooperation was founded to bridge the gap between advanced engineering
              and Africa's industrial needs. We design, build, and deploy scalable solutions that
              solve real problems — from smart poultry farming to urban safety systems.
            </p>

            <div className="flex items-start gap-4 p-4 bg-surface rounded-sm border border-border">
              <Eye size={20} className="text-primary mt-0.5 shrink-0" />
              <div>
                <p className="font-display font-semibold text-sm mb-1">10+ Year Vision</p>
                <p className="text-sm text-muted-foreground">
                  Become the leading engineering-first tech company building Africa's smart infrastructure layer.
                </p>
              </div>
            </div>
          </div>

          <div>
            <p className="text-primary font-display text-sm tracking-[0.2em] uppercase mb-4">
              5 Operating Sectors
            </p>
            <div className="space-y-3">
              {sectors.map((sector, i) => (
                <div
                  key={sector}
                  className="flex items-center gap-4 p-4 bg-surface rounded-sm border border-border group hover:border-primary/30 transition-colors"
                >
                  <div className="w-8 h-8 rounded-sm bg-primary/10 flex items-center justify-center text-primary font-display text-sm font-bold">
                    {String(i + 1).padStart(2, "0")}
                  </div>
                  <span className="font-display text-sm font-medium">{sector}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
