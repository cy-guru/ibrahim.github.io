const roadmap = [
  { year: "2026", title: "MVP Development & Validation", desc: "Build, test, and iterate on core products with real users and environments." },
  { year: "2027", title: "Industry Pilots & Testing", desc: "Deploy pilot programs with strategic partners across East Africa." },
  { year: "2028", title: "Manufacturing & Scaling", desc: "Begin local manufacturing and scale proven solutions to new markets." },
  { year: "2030", title: "Smart Infrastructure Expansion", desc: "Expand into continental smart infrastructure and IoT ecosystem plays." },
];

export default function RoadmapSection() {
  return (
    <section id="roadmap" className="section-padding">
      <div className="max-w-4xl mx-auto">
        <div className="gold-line mb-16" />

        <p className="text-primary font-display text-sm tracking-[0.2em] uppercase mb-4">
          Strategic Roadmap
        </p>
        <h2 className="font-display text-3xl md:text-4xl font-bold mb-16">
          The Path <span className="text-gradient-gold">Forward</span>
        </h2>

        <div className="relative">
          <div className="absolute left-[19px] top-0 bottom-0 w-px bg-border" />

          <div className="space-y-10">
            {roadmap.map((item) => (
              <div key={item.year} className="flex items-start gap-6 relative">
                <div className="w-10 h-10 rounded-full bg-background border-2 border-primary/40 flex items-center justify-center shrink-0 z-10">
                  <div className="w-2.5 h-2.5 rounded-full bg-primary" />
                </div>
                <div className="bg-surface border border-border rounded-sm p-6 flex-1 hover:border-primary/20 transition-colors">
                  <p className="text-primary font-display font-bold text-sm mb-1">{item.year}</p>
                  <h3 className="font-display text-lg font-semibold mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
